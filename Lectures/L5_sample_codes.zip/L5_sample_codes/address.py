
class Address:
    def __init__(self, id, address, postal):
        self.id = id
        self.address = address
        self.postal = postal

    def __str__(self):
        return f"Address[[{self.address} {self.postal}]]"