
class Person:
    def __init__(self, id, name, age, contact_number, address):
        self.id = id
        self.name = name
        self.age = age
        self.contact_number = contact_number
        self.address = address

    def __str__(self):
        return f"PERSON[[{self.name} is {self.age} years old and lives at\n\t{self.address}]"
