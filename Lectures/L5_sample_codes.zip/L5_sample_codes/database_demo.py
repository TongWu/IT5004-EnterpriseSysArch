import sqlite3
from person import Person
from address import Address

DATABASE_PATH = "database.sqlite"

# define the functions to interact with the database
def create_connection(db_file):
    """ create a database connection to a SQLite database """
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except sqlite3.Error as e:
        print(e)
    return None

def create_tables():
    conn = create_connection(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE address
                 (id integer primary key, 
                  address text, 
                  postal text)''')
    
    cursor.execute('''CREATE TABLE person
                 (id integer primary key, 
                  name text, 
                  age integer,
                  contact_number text,
                  address_id integer,
                  FOREIGN KEY (address_id) REFERENCES address(id))''')
    conn.commit()
    conn.close()


def insert_data():
    conn = create_connection(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO address (address, postal) 
        VALUES ('Blk 322 Clementi Avenue 5', '120322')
    ''')

    cursor.execute('''
        INSERT INTO address (address, postal) 
        VALUES ('Blk 538 Pasir Ris Street 51', '510538')
    ''')

    cursor.execute('''
        INSERT INTO person (name, age, contact_number, address_id) 
        VALUES ('John', 20, '91234567', 1)
    ''')

    cursor.execute('''
        INSERT INTO person (name, age, contact_number, address_id)
        VALUES ('Mary', 18, '97654321', 2)
    ''')
    
    conn.commit()
    conn.close()

def get_all_person():
    conn = create_connection(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        SELECT person.id, person.name, person.age, person.contact_number, address.id, address.address, address.postal
        FROM person
        INNER JOIN address ON person.address_id = address.id
    ''')
    rows = cursor.fetchall()
    persons = []
    for row in rows:
        address = Address(row[4], row[5], row[6])
        person = Person(row[0], row[1], row[2], row[3], address)
        persons.append(person)

    conn.close()
    return persons


if __name__ == '__main__':
    # Uncomment the following lines to create the database
    # create_tables()
    # insert_data()
    
    people = get_all_person()

    for person in people:
        print(person)
        print("====================================")