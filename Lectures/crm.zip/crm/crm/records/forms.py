from django import forms


class NewCustomerForm(forms.Form):
    name = forms.CharField(required=True)
    age = forms.IntegerField(required=True)
