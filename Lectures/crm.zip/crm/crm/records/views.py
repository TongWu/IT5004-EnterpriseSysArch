from django.shortcuts import render
from django.http import HttpResponseRedirect
from .forms import NewCustomerForm
from .models import Customer


# Create your views here.


def about(request):
    # Normally retrieve data from the data
    # But we will just simulate using a fake dictionary
    # pass the data as the 3rd parameter to the view
    return render(request, 'aboutme.html', {'name': 'John Doe', 'age': 20})


def newContact(request):
    if request.method == 'POST':
        # grab data from the form
        form = NewCustomerForm(request.POST)

        # check if the form is valid:
        if form.is_valid():
            name = form.cleaned_data['name']
            age = form.cleaned_data['age']
            c = Customer(name=name, age=age)
            c.save()
            print(c)
            return HttpResponseRedirect('/list')
        else:
            pass
    else:
        # GET request
        form = NewCustomerForm()
        return render(request, 'new.html', {'form_html': form.as_table()})


def list(request):
    customers = Customer.objects.all()
    print('customers', customers)
    return render(request, 'list.html', {'customers': customers})


def deleteContact(request):
    id = request.GET.get('id')
    # delete customer
    Customer.objects.filter(id=id).delete()

    return HttpResponseRedirect('/list')
