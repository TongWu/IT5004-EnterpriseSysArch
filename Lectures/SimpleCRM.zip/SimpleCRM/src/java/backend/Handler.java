package backend;

import dataaccess.DatabaseHelper;
import entity.Customer;
import java.util.List;

//This class handles all the business logic.
//It makes use of the data access layer to complete the different functionalities
public class Handler {

    public List<Customer> getAllCustomers() {
        return DatabaseHelper.getAllCustomers();
    } //end getAllCustomers

    public void addCustomer(String name, String phone) {
        Customer c = new Customer(name, phone);
        DatabaseHelper.addCustomer(c);
    } //end addCustomer

    public void deleteCustomer(Long cId) {
        DatabaseHelper.deleteCustomer(cId);
    } //end deleteCustomer
}
