package webserver;

import backend.Handler;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//This class is the Controller class which determines what the client (presentation
//layer) wants to do and uses the handler class to perform the operations
//i.e. the actual logic is not performed here. Instead, the handler is the one
//performing the business logic
@WebServlet(name = "Controller", urlPatterns = {"/Controller/*"})
public class Controller extends HttpServlet {

    Handler handler = new Handler();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String path = request.getPathInfo();

            System.out.println("#in processRequest: " + path);

            switch (path) {
                case "/doCreateCustomer":
                    //perform create customer logic
                    String name = request.getParameter("name");
                    String phone = request.getParameter("phone");
                    handler.addCustomer(name, phone);
                    //--------------------------------

                    response.sendRedirect(request.getContextPath()
                            + "/Controller/");
                    return;

                case "/doDeleteCustomer":
                    //perform delete customer logic
                    String cIdStr = request.getParameter("cId");
                    Long cId = Long.parseLong(cIdStr);
                    handler.deleteCustomer(cId);
                    //--------------------------------

                    response.sendRedirect(request.getContextPath()
                            + "/Controller/");
                    return;

            }

            request.setAttribute("customers", handler.getAllCustomers());
        } catch (Exception e) {
            //ignore all error
        }

        //always show the index.jsp page
        request.getRequestDispatcher("/customers.jsp").forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
