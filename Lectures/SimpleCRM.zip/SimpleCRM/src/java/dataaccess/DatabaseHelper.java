package dataaccess;

import entity.Customer;
import java.util.ArrayList;
import java.util.List;

//This class acts like a data access layer.
//All database related operation should be performed using this class
public class DatabaseHelper {

    private static long nextId = 1;

    //simulate the database using a simple AraryList
    private static List<Customer> data = new ArrayList<Customer>();

    public static List<Customer> getAllCustomers() {
        return data;
    } //end getAllCustomers

    public static void addCustomer(Customer c) {

        //simulate auto generate of ID
        c.setId(nextId++);

        data.add(c);
    } //end addCustomer

    public static void deleteCustomer(Long cId) {
        Customer c = new Customer();
        c.setId(cId);

        data.remove(c);
    } //end deleteCustomer
}
