
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Simple Customer Relationship Management System</title>
    </head>
    <body>
        <h1>New Customer</h1>
        <form action="doCreateCustomer" method="POST">
            <label for="name">Name: </label><input type="text" id="name" name="name" /><br />
            <label for="name">Phone: </label><input type="text" id="phone" name="phone" /><br />
            <input type="submit" value="Submit" />
        </form>

        <h1>Customer List</h1>
        <c:forEach var="customer" items="${customers}">
            <div style="border: 1px brown solid; padding: 10px;">
                Id: ${customer.id}<br />
                Name: ${customer.name}<br />
                Phone: ${customer.phone}<br />

                <form action="doDeleteCustomer"  method="POST">
                    <input type="hidden" name="cId" value="${customer.id}">
                    <input type="submit" value="Delete Customer">
                </form>
            </div>
        </c:forEach>
    </body>
</html>
